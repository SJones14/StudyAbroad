﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Pages;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            CountryModel objcountrymodel = new CountryModel();
            
            return View(objcountrymodel);
        }
        public List<SelectListItem> CountryDate()
        {
            List<SelectListItem> objcountry = new List<SelectListItem>();
            //objcountry.Add(new Country { CountryName = "America" });
            // objcountry.Add(new Country { CountryName = "India" });
            //objcountry.Add(new Country { CountryName = "Sri Lanka" });
            //objcountry.Add(new Country { CountryName = "China" });
            //objcountry.Add(new Country { CountryName = "Pakistan" });
            
            return objcountry;
        }
    }
}
