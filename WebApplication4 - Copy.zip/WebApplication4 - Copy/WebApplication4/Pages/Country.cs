﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Controllers;

namespace WebApplication4.Pages
{
    public class CountryModel
    {
        public SelectList CountryList { get; set; } = Load_Countries();
        public string SelectedCountryId { get; set; }
        public static SelectList Load_Countries()
        {
            List<SelectListItem> CountryList = new List<SelectListItem>()
        {
            new SelectListItem(){Value = "USA", Text="USA"}
        };
            return new SelectList(CountryList, "value", "Text");
        }
    }
    public class Country
    {
        public string CountryName { get; set; }
    }
    
}
